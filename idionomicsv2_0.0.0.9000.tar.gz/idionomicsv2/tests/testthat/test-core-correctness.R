# Verifies that iarimax produces the same numbers as running each
# step manually. These tests are slow (auto.arima runs twice per subject:
# once inside iarimax and once in the manual comparison below) and are
# skipped on CRAN.

skip_on_cran()

panel  <- make_panel(n_subjects = 3, n_obs = 25, seed = 42)
result <- iarimax(dataframe = panel, y_series = "y", x_series = "x",
                  id_var = "id", timevar = "time")

subjects <- unique(panel$id)

# Helper: reproduce exactly what iarimax does for one subject.
manual_fit <- function(data, subj) {
  sub   <- data[data$id == subj, ]
  sub   <- sub[order(sub$time), ]
  y_vec <- sub$y
  x_mat <- as.matrix(sub[, "x", drop = FALSE])

  model <- forecast::auto.arima(y = y_vec, xreg = x_mat,
                                approximation = FALSE, stepwise = FALSE)
  class(model) <- setdiff(class(model), "ARIMA")  # mirrors iarimax's workaround

  list(
    model  = model,
    tidy   = broom::tidy(model),
    cor_p  = suppressWarnings(
      stats::cor.test(sub$x, sub$y, method = "pearson")
    )$estimate[[1]],
    cor_s  = suppressWarnings(
      stats::cor.test(sub$x, sub$y, method = "spearman")
    )$estimate[[1]]
  )
}

# ── xreg coefficient ─────────────────────────────────────────────────────────

test_that("estimate_x matches manual auto.arima for each subject", {
  for (subj in subjects) {
    m       <- manual_fit(panel, subj)
    pkg_row <- result$results_df[result$results_df$id == subj, ]
    expect_equal(
      pkg_row$estimate_x,
      m$tidy$estimate[m$tidy$term == "x"],
      tolerance = 1e-8,
      label = paste("estimate_x for subject", subj)
    )
  }
})

test_that("std.error_x matches manual auto.arima for each subject", {
  for (subj in subjects) {
    m       <- manual_fit(panel, subj)
    pkg_row <- result$results_df[result$results_df$id == subj, ]
    expect_equal(
      pkg_row$std.error_x,
      m$tidy$std.error[m$tidy$term == "x"],
      tolerance = 1e-8,
      label = paste("std.error_x for subject", subj)
    )
  }
})

# ── ARIMA orders ──────────────────────────────────────────────────────────────

test_that("ARIMA order (nAR, nI, nMA) matches manual auto.arima for each subject", {
  for (subj in subjects) {
    m       <- manual_fit(panel, subj)
    pkg_row <- result$results_df[result$results_df$id == subj, ]
    expect_equal(unname(pkg_row$nAR), m$model$arma[1], label = paste("nAR for subject", subj))
    expect_equal(unname(pkg_row$nI),  m$model$arma[6], label = paste("nI  for subject", subj))
    expect_equal(unname(pkg_row$nMA), m$model$arma[2], label = paste("nMA for subject", subj))
  }
})

# ── Raw correlation ───────────────────────────────────────────────────────────

test_that("raw_cor (pearson) matches manual cor.test for each subject", {
  for (subj in subjects) {
    m       <- manual_fit(panel, subj)
    pkg_row <- result$results_df[result$results_df$id == subj, ]
    expect_equal(unname(pkg_row$raw_cor), m$cor_p, tolerance = 1e-10,
                 label = paste("raw_cor for subject", subj))
  }
})

test_that("raw_cor (spearman) matches manual cor.test for each subject", {
  result_s <- iarimax(dataframe = panel, y_series = "y", x_series = "x",
                      id_var = "id", timevar = "time",
                      correlation_method = "spearman")
  for (subj in subjects) {
    m       <- manual_fit(panel, subj)
    pkg_row <- result_s$results_df[result_s$results_df$id == subj, ]
    expect_equal(unname(pkg_row$raw_cor), m$cor_s, tolerance = 1e-10,
                 label = paste("spearman raw_cor for subject", subj))
  }
})

# ── n_valid ───────────────────────────────────────────────────────────────────

test_that("n_valid matches stats::nobs of manual model for each subject", {
  for (subj in subjects) {
    m       <- manual_fit(panel, subj)
    pkg_row <- result$results_df[result$results_df$id == subj, ]
    expect_equal(unname(pkg_row$n_valid), stats::nobs(m$model),
                 label = paste("n_valid for subject", subj))
  }
})

# ── Temporal ordering ─────────────────────────────────────────────────────────

test_that("shuffled input gives identical results to sorted input", {
  set.seed(99)
  shuffled        <- panel[sample(nrow(panel)), ]
  result_shuffled <- iarimax(dataframe = shuffled, y_series = "y", x_series = "x",
                             id_var = "id", timevar = "time")

  r1 <- result$results_df[order(result$results_df$id), ]
  r2 <- result_shuffled$results_df[order(result_shuffled$results_df$id), ]

  expect_equal(r1$estimate_x,  r2$estimate_x,  tolerance = 1e-8)
  expect_equal(r1$std.error_x, r2$std.error_x, tolerance = 1e-8)
  expect_equal(r1$raw_cor,     r2$raw_cor,     tolerance = 1e-10)
  expect_equal(r1$nAR,         r2$nAR)
  expect_equal(r1$nI,          r2$nI)
  expect_equal(r1$nMA,         r2$nMA)
})
