#' Run I-ARIMAX algorithm.
#'
#' @export
#' @importFrom utils globalVariables
#' @importFrom rlang :=
#'
#' @param dataframe Your dataframe.
#' @param min_n_subject The minimum number of non NA cases to run the analyses. It will filter cases with more NA's than the threshold. Defaults to 20.
#' @param minvar The minimum variance for both series (&) to include a case. Defaults to 0.01.
#' @param y_series A string containing the name of your dependent variable y.
#' @param x_series A character vector containing the name(s) of your predictor variable(s).
#' @param focal_predictor A string with the name of the predictor to use in the meta-analysis. Required when x_series has more than one variable. When x_series is a single variable, defaults to that variable.
#' @param id_var A string containing your id variable.
#' @param timevar Required to arrange timeseries.
#' @param correlation_method Select method for raw correlations. Options are: 'spearman', 'pearson' or 'kendall'. Defaults to 'pearson'.
#' @param keep_models If TRUE, will keep original arimax models in a list.
#' @param verbose If TRUE, prints progress messages during filtering and model fitting. Defaults to FALSE.
#'
#' @returns A list containing a dataframe with the ARIMA parameters, plus the xreg parameters (the beta values for your x_series) together with their std.errors, and a random effects meta analysis on the focal predictor.


#######################################
############ I ARIMAX FUNCTION #######
#####################################

iarimax <- function(dataframe, min_n_subject = 20, minvar = 0.01, y_series, x_series,
                    focal_predictor = NULL, id_var, timevar,
                    correlation_method = 'pearson', keep_models = FALSE, verbose = FALSE) {

  # Check wether variables are in the in the dataset.
  required_vars <- c(y_series, x_series, id_var, timevar)

  if (!all(required_vars %in% colnames(dataframe))) {
    missing_vars <- required_vars[!required_vars %in% colnames(dataframe)]
    stop(paste("Cannot find required variables. Check if you spelled the following variables correctly:", paste(missing_vars, collapse = ", ")))
  }

  #Check for timevar missing data: With missings, the data cannot be arranged, so this is a really important guardrail.
  n_missing_timevar <- sum(is.na(dataframe[[timevar]]))
  if (n_missing_timevar > 0) {
    stop(
      n_missing_timevar, " row(s) have missing values in the time variable '", timevar, "'. ",
      "iarimax requires a non-missing timevar for every observation to ensure correct temporal ordering. ",
      "Please review, remove or impute these rows before running iarimax."
    )
  }

  # Resolve focal_predictor: default to x_series when only one predictor is given.
  if (is.null(focal_predictor)) {
    if (length(x_series) == 1) {
      focal_predictor <- x_series
    } else {
      stop("focal_predictor is required when x_series contains more than one variable.")
    }
  }

  if (!focal_predictor %in% x_series) {
    stop(paste("focal_predictor must be one of the x_series variables. Got:", focal_predictor))
  }

  # Convert strings to rlang::symbols
  y_series_sym <- rlang::sym(y_series)
  id_var_sym <- rlang::sym(id_var)
  timevar_sym <- rlang::sym(timevar)

  #Id var as character, to avoid numerics and giant lists.
  dataframe[[id_var]] <- as.character(dataframe[[id_var]])


  #Subset only relevant features.
  dataframe <- dataframe[, required_vars, drop = FALSE]

  if (verbose) message('Filtering data based on minimum non-NA observations and variance...')

  # Filter N pairwise complete observations with variance conditions
  subjects <- dataframe |>
    dplyr::group_by(!!id_var_sym) |> #Group by id variable.
    dplyr::filter(!is.na(!!y_series_sym) &
                    dplyr::if_all(dplyr::all_of(x_series), ~ !is.na(.x))) |> #Filter all that are complete in all variables.
    dplyr::summarise(
      count = dplyr::n(), #Use counts to filter.
      var_y = stats::var(!!y_series_sym, na.rm = TRUE), #use variance to filter.
      dplyr::across(dplyr::all_of(x_series), ~ stats::var(.x, na.rm = TRUE), .names = "var_{.col}"), #Variance for each predictor.
      .groups = 'drop'
    ) |>
    dplyr::filter(count >= min_n_subject,
                  dplyr::if_all(dplyr::starts_with("var_"), ~ .x >= minvar)) |> #y and all predictors must meet minvar.
    dplyr::pull(!!id_var_sym) #Filter data.

  #ID as character, to avoid giant lists.
  subjects <- as.character(subjects)

  #Stop if not enough subjects.
  if (length(subjects) <= 1){
    stop(paste("There are not enough cases to run the iarimax algorithm. You have", length(subjects),"valid cases."))
  }

  if (verbose) {
    message('Filtering done: ', length(subjects), ' subjects will be used for the analyses.')
    message('Running I-ARIMAX algorithm...')
  }

  #Storage lists.

  #Number of valid cases & parameters.
  n_valid <- list()
  n_params <- list()

  #Exclude cases where arimax don't work.
  exclude <- character(0)

  #Model lists.
  arimax_models <- list()
  tidy_models <- list()
  raw_correlation <- list()
  AR_N <- list()
  I_N <- list()
  MA_N <- list()


  #Start case number counter.
  casen = 0
  for(i in subjects) {

    #Update case number.
    casen <- casen + 1

    if (verbose) message('  Applying auto ARIMAX to case: ', i, ' ... ', appendLF = FALSE) # appendLF = FALSE keeps cursor on same line so the completion percentage prints right after.

    #Extract the current subject & arrange timeseries by timevar.
    subject_n <- dataframe |>
      dplyr::filter(!!id_var_sym == i) |>
      dplyr::arrange(!!timevar_sym) #Ensure time-series order.

    ##########################################
    ### A COMMENT OF MISSING DATA HANDLING ###
    #########################################

    # Note: We do NOT need to manually sync NAs.
    # stats::arima's Kalman Filter (C source) automatically treats
    # any row with a missing predictor as a missing observation
    # in the state-space update, preserving temporal structure.

    #Extract y vector.
    y_vector <- subject_n |>
      dplyr::pull(!!y_series_sym)

    #Extract x matrix (one column per predictor, named).
    x_matrix <- as.matrix(subject_n[, x_series, drop = FALSE])


    ########################
    #### Calculate cor #####
    ########################

    # Correlation is computed for the focal predictor only.
    focal_vector <- subject_n |> dplyr::pull(focal_predictor)

    correlation <- tryCatch(
      {#Supress spearman's warning about p-values with ties.
        suppressWarnings(stats::cor.test(x = focal_vector, y = y_vector, method = correlation_method))
      },
      error = function(e) {
        message('\nError computing correlation for case: ', i, '\n  ', e$message)
        NULL #Set model as NULL
      }
    )

    #Handle when correlations are null.
    if (is.null(correlation)) {
      raw_correlation[[i]] <- NA
    } else {
      raw_correlation[[i]] <- correlation$estimate[1]
    }

    ##############################
    ### CALCULATE AUTO.ARIMA ####
    ############################

    model <- tryCatch(
      {
        forecast::auto.arima(y = y_vector, xreg = x_matrix, approximation = FALSE, stepwise = FALSE)
      },
      error = function(e) {
        message('\nError running ARIMAX model for case: ', i, '\n  ', e$message)
        NULL #Set model as NULL
      }
    )

    #Fill the list with NA if the model is null

    if (is.null(model)) {
      AR_N[[i]] <- NA
      I_N[[i]] <- NA
      MA_N[[i]] <- NA
      n_valid[[i]] <- NA
      n_params[[i]] <- NA
      tidy_models[[i]] <- NULL
      arimax_models[[i]] <- NULL

      exclude <- c(exclude,i)

      if (verbose) message('skipped. (', round(casen / length(subjects) * 100, 1), '% done)')
      next #Skip the next part of this iteration of the loop, so it doesn't get overriden and throws an error.
    }

    # Remove fable's "ARIMA" class to prevent it from hijacking broom::tidy.
    class(model) <- setdiff(class(model), "ARIMA")
    tidymodel <- broom::tidy(model)

    #Add id to tidy model.
    tidymodel <- tidymodel |>
      dplyr::mutate(!!id_var_sym := i)

    #Fill the tidy model list.
    tidy_models[[i]] <- tidymodel
    # Conditional storage of raw models
    if (keep_models) {
      arimax_models[[i]] <- model
    } else {
      arimax_models[[i]] <- NULL # Placeholder to keep list lengths consistent
    }


    #Fill the number of ARIMA parameteres lists: Just the number of AR I MA processes involved.
    AR_N[[i]] <- model$arma[1] #Fill AR list.
    I_N[[i]] <- model$arma[6] #Fill I list.
    MA_N[[i]] <- model$arma[2] #Fill MA List.

    #Fill n valid and n params. nobs() returns the n used in the model likelihood.
    n_valid[[i]] <- stats::nobs(model)
    n_params[[i]] <- length(model$coef)


    if (verbose) message(round(casen / length(subjects) * 100, 1), '% done')
  }

  ###############################################
  ### CREATE DATAFRAME WITH PARAMETERS ##########
  ###############################################
  #Filter null models.
  tidy_list <- Filter(Negate(is.null), tidy_models)

  #Stop if no valid model is present.
  if (length(tidy_list) == 0) {
    stop(
      "iarimax: all ARIMAX fits failed after filtering. ",
      "No subject produced a valid model. ",
      "Check (a) time ordering / timevar, (b) missingness in y/x, ",
      "(c) min_n_subject/minvar thresholds, and (d) whether xreg has NA patterns."
    )
  }

  #Create tidy long.
  tidy_long <- dplyr::bind_rows(tidy_list)


  # Pivot the coefficients to wide format.
  # Term names come from the xreg column names, e.g. estimate_stress, std.error_stress, estimate_ar1, etc.
  tidy_wide <- tidy_long |>
    tidyr::pivot_wider(
      id_cols     = !!id_var_sym,
      names_from  = "term",
      values_from = c("estimate", "std.error")
    )


  # Convert the lists to vectors
  AR_vector <- unlist(AR_N)
  I_vector <- unlist(I_N)
  MA_vector <- unlist(MA_N)
  n_valid_vector <- unlist(n_valid)
  n_params_vector <- unlist(n_params)
  raw_correlation_vector <- unlist(raw_correlation)


  #Create individual level summaries.
  summary_df <- tibble::tibble(
    !!id_var_sym := subjects,
    nAR = AR_vector,
    nI = I_vector,
    nMA = MA_vector,
    raw_cor = raw_correlation_vector,
    n_valid = n_valid_vector,
    n_params = n_params_vector
  )

  #Create dataframe to return.

  results_df <- summary_df |>
    dplyr::left_join(tidy_wide, by = id_var)


  ##############################################
  ##### RUN RANDOM EFFECTS META ANALYSIS ######
  #############################################

  #Try running the random effects meta analysis.

  focal_est_col <- paste0("estimate_",  focal_predictor)
  focal_se_col  <- paste0("std.error_", focal_predictor)

  meta_analysis <-
    tryCatch(
      {
        metafor::rma(yi = results_df[[focal_est_col]], sei = results_df[[focal_se_col]], method = "REML")
      },
      error = function(e) {
        message('Error running meta-analysis: ', e$message, '. meta_analysis will be NULL in the output.')
        NULL
      }
    )

  final_obj <- list(results_df = results_df,
                    meta_analysis = meta_analysis,
                    error_arimax_skipped = exclude,
                    models = if (keep_models) arimax_models else NULL)

  #Add class to identify the object.
  class(final_obj) <- c("iarimax_results", "list")

  #Add attribute to identify focal predictor, and id_var.
  attr(final_obj, "focal_predictor") <- focal_predictor
  attr(final_obj, "id_var") <- id_var
  attr(final_obj, "timevar") <- timevar


  if (verbose) message('I-ARIMAX algorithm finished.')

  return(final_obj)

}


utils::globalVariables(c("count", "var_y")) #Declare symbolic global variables.
